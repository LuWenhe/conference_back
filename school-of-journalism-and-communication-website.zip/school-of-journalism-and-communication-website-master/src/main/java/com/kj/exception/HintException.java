package com.kj.exception;

/**
 * @author 破晓
 * @date 2022-01-09 17:34
 */
public class HintException extends RuntimeException {

    public HintException() {
    }

    public HintException(String message) {
        super(message);
    }
}
