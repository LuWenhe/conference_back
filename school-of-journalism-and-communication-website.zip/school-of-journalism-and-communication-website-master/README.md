# 新闻学院官网

#### 介绍
新闻与传播学院官网

#### 软件架构
软件架构说明（前后端分离）

- 后端：SpringBoot、Shiro、Mybatis-Plus

- 前端gitee：https://gitee.com/rendongc/xin-chuan.git

#### 预览图片
Swagger
![输入图片说明](static/images/swagger.png)
前端页面
![输入图片说明](static/images/image2.png)
![输入图片说明](static/images/image.png)
![输入图片说明](static/images/image3.png)
![输入图片说明](static/images/image4.png)
![输入图片说明](static/images/image5.png)
![输入图片说明](static/images/image6.png)
![输入图片说明](static/images/image7.png)

